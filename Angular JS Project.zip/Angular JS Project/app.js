angular.module('bookstoreApp', [])
.controller('BookstoreController', function() {
    this.name = 'My Online Bookstore';
    this.books = [
        { id: 1, title: 'Book One', author: 'Author One', price: 19.99, imageUrl: 'img1.png' },
        { id: 2, title: 'Book Two', author: 'Author Two', price: 29.99, imageUrl: 'img2.jpeg' },
        { id: 3, title: 'Book Three', author: 'Author Three', price: 39.99, imageUrl: 'img3.jpg' }
    ];
    this.cart = [];

    this.addToCart = function(book) {
        var bookInCart = this.cart.find(function(cartBook) {
            return cartBook.id === book.id;
        });

        if (!bookInCart) {
            this.cart.push(book);
            alert(book.title + ' added to cart!');
        } else {
            alert(book.title + ' is already in the cart.');
        }
    };

    this.getTotalAmount = function() {
        return this.cart.reduce(function(total, book) {
            return total + book.price;
        }, 0);
    };
});