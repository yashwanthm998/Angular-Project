angular.module('bookstoreApp', [])
.controller('BookstoreController', function() {
    this.name = 'My Online Bookstore';
    this.books = [
        { id: 1, title: 'Harry Potter and The Cursed Child', author: 'J. K. Rowling', price: 19.99, imageUrl: 'img1.jpeg' },
        { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee', price: 29.99, imageUrl: 'img2.webp' },
        { id: 3, title: 'Harry Potter and the Deadly Hallows', author: 'J. K. Rowling', price: 39.99, imageUrl:'img3.jpeg' },
        { id: 4, title: 'A Little Life', author: 'Hanya Yanagihara', price: 45.99, imageUrl: 'img4.jpg' },
        { id: 5, title: 'Darkmans', author: 'Nicola Barker', price: 50.99, imageUrl: 'img5.jpg' },
        { id: 6, title: 'The Siege', author: 'Helen Dunmore ', price: 38.99, imageUrl: 'img6.jpg' },
        { id: 7, title: 'The Silent Patient', author: 'Alex Michaelides', price: 60.99, imageUrl: 'img7.jpg' },
        { id: 8, title: 'The Merchant of Venice', author: 'William Shakespeare', price: 22.99, imageUrl: 'img8.jpg' },
        { id: 9, title: 'Only If You are Lucky', author: ' Stacy Willingham', price: 41.99, imageUrl: 'img9.jpeg' },
        { id: 10, title: 'Twenty-Seven Minutes', author: 'Ashley Tate', price: 34.99, imageUrl: 'img10.jpeg' },
        { id: 11, title: 'This Wretched Valley', author: 'Jenny Kiefer', price: 25.99, imageUrl: 'img11.jpeg' },
        { id: 12, title: 'The Woman on the Ledge', author: 'Ruth Mancini', price: 29.99, imageUrl: 'img12.jpeg' }
    ];
    this.cart = [];

    this.addToCart = function(book) {
        var bookInCart = this.cart.find(function(cartBook) {
            return cartBook.id === book.id;
        });

        if (!bookInCart) {
            this.cart.push(book);
            //alert(book.title + ' added to cart!');
        } else {
            alert(book.title + ' is already in the cart.');
        }
    };

    this.getTotalAmount = function() {
        return this.cart.reduce(function(total, book) {
            return total + book.price;
        }, 0);
    };
    this.removeFromCart = function(index) {
        this.cart.splice(index, 1);
    };
});